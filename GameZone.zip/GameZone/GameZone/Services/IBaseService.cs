﻿namespace GameZone.Services
{
	public interface IBaseService
	{
		//UpdateAuditInfo(Game game, bool IsNew);
	}
}

