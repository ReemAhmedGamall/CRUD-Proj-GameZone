﻿using GameZone.Interface;
using Microsoft.AspNetCore.Http.HttpResults;

namespace GameZone.Services
{
	public class BaseService : IBaseService
	{
		//public DateTime? CreatedOn { get; set; }
		//public DateTime? UpdatedOn { get; set; }

		public void UpdateAuditInfo<T>(T entity, bool IsNew) where T : class, IAuditInfo
		{
			if (IsNew)
			{
				entity.CreatedOn = DateTime.UtcNow;
			}
			else
			{
				entity.UpdatedOn = DateTime.UtcNow;
			}
		}
	}
}
