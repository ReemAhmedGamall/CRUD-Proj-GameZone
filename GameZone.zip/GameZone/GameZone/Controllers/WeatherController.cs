﻿using Microsoft.AspNetCore.Mvc;
using OpenMeteo;
using Newtonsoft.Json;
using System.Net.Http;
using System.Web;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;

//namespace GameZone.Controllers
//{
//	public class WeatherController : Controller
//	{
//		public async Task<IActionResult> Index()
//		{
//			//string cairo = "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m&timezone=Africa%2FCairo&forecast_days=1";
//			//string newYork = "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m&timezone=America%2FNew_York&forecast_days=1";

//			WeatherModel weatherModel = new WeatherModel();

//			using (var httpClient = new HttpClient())
//			{
//				var cairoResponse = await httpClient.GetStringAsync("https://api.open-meteo.com/v1/forecast?latitude=30.0444&longitude=31.2357&current_weather=true");
//				// Call the API for New York's weather
//				var newYorkResponse = await httpClient.GetStringAsync("https://api.open-meteo.com/v1/forecast?latitude=30.0444&longitude=31.2357&current_weather=true");

//				// Parse the JSON response for Cairo
//				var cairoWeatherData = JsonConvert.DeserializeObject<WeatherData>(cairoResponse);
//				// Parse the JSON response for New York
//				var newYorkWeatherData = JsonConvert.DeserializeObject<WeatherData>(newYorkResponse);

//				// Fill the WeatherModel properties with the temperature data
//				weatherModel.CairoWeather = cairoWeatherData.current_weather.temperature.ToString();
//				weatherModel.NewYorkWeather = newYorkWeatherData.current_weather.temperature.ToString();

//			}

//			//weatherModel.CairoWeather = cairo;
//			//weatherModel.NewYorkWeather = newYork;

//			return View(weatherModel);
//		}
//	}


//}


public class WeatherController : Controller
{
    public async Task<IActionResult> Index()
    { return View(); }

    public async Task<IActionResult> Current()
    {
        WeatherModel weatherModel = new WeatherModel();

        using (var httpClient = new HttpClient())
        {
            var cairoUriBuilder = new UriBuilder("https://api.open-meteo.com/v1/forecast");
            var cairoQuery = System.Web.HttpUtility.ParseQueryString(string.Empty);
            cairoQuery["latitude"] = "30.0444";
            cairoQuery["longitude"] = "31.2357";
            cairoQuery["current_weather"] = "true";
            cairoUriBuilder.Query = cairoQuery.ToString();
            var cairoUrl = cairoUriBuilder.ToString();

            var newYorkUriBuilder = new UriBuilder("https://api.open-meteo.com/v1/forecast");
            var newYorkQuery = System.Web.HttpUtility.ParseQueryString(string.Empty);
            newYorkQuery["latitude"] = "40.7128";
            newYorkQuery["longitude"] = "-74.0060";
            newYorkQuery["current_weather"] = "true";
            newYorkUriBuilder.Query = newYorkQuery.ToString();
            var newYorkUrl = newYorkUriBuilder.ToString();

            var cairoResponse = await httpClient.GetStringAsync(cairoUrl);
            var newYorkResponse = await httpClient.GetStringAsync(newYorkUrl);

            var cairoWeatherData = JsonConvert.DeserializeObject<WeatherData>(cairoResponse);
            var newYorkWeatherData = JsonConvert.DeserializeObject<WeatherData>(newYorkResponse);

            weatherModel.CairoWeather = cairoWeatherData?.current_weather?.temperature.ToString() ?? "Data not available";
            weatherModel.NewYorkWeather = newYorkWeatherData?.current_weather?.temperature.ToString() ?? "Data not available";
        }
        return PartialView("_Current", weatherModel);
    }


    public async Task<IActionResult> Week()
    {
        WeatherModel weatherModel = new WeatherModel
        {
            CairoWeekWeather = new List<DailyWeather>(),
            NewYorkWeekWeather = new List<DailyWeather>()
        };

        using (var httpClient = new HttpClient())
        {
            // Cairo
            var cairoUriBuilder = new UriBuilder("https://api.open-meteo.com/v1/forecast");
            var cairoQuery = System.Web.HttpUtility.ParseQueryString(string.Empty);
            cairoQuery["latitude"] = "30.0444";
            cairoQuery["longitude"] = "31.2357";
            cairoQuery["daily"] = "temperature_2m_max";
            cairoQuery["forecast_days"] = "7";
            cairoUriBuilder.Query = cairoQuery.ToString();
            var cairoUrl = cairoUriBuilder.ToString();

            // New York
            var newYorkUriBuilder = new UriBuilder("https://api.open-meteo.com/v1/forecast");
            var newYorkQuery = System.Web.HttpUtility.ParseQueryString(string.Empty);
            newYorkQuery["latitude"] = "40.7128";
            newYorkQuery["longitude"] = "-74.0060";
            newYorkQuery["daily"] = "temperature_2m_max";
            newYorkQuery["forecast_days"] = "7";
            newYorkUriBuilder.Query = newYorkQuery.ToString();
            var newYorkUrl = newYorkUriBuilder.ToString();

            var cairoResponse = await httpClient.GetStringAsync(cairoUrl);
            var newYorkResponse = await httpClient.GetStringAsync(newYorkUrl);

            var cairoWeatherData = JsonConvert.DeserializeObject<WeatherData>(cairoResponse);
            var newYorkWeatherData = JsonConvert.DeserializeObject<WeatherData>(newYorkResponse);

            for (int i = 0; i < cairoWeatherData.daily.time.Count; i++)
            {
                weatherModel.CairoWeekWeather.Add(new DailyWeather
                {
                    Date = cairoWeatherData.daily.time[i],
                    MaxTemperature = cairoWeatherData.daily.temperature_2m_max[i]
                });
            }

            // Fill the WeatherModel properties for New York
            for (int i = 0; i < newYorkWeatherData.daily.time.Count; i++)
            {
                weatherModel.NewYorkWeekWeather.Add(new DailyWeather
                {
                    Date = newYorkWeatherData.daily.time[i],
                    MaxTemperature = newYorkWeatherData.daily.temperature_2m_max[i]
                });
            }
        }
        return PartialView("_Week", weatherModel);
    }
}