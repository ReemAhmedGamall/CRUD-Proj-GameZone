﻿namespace GameZone.Interface
{
	public interface IAuditInfo
	{
		DateTime? CreatedOn { get; set; }
		DateTime? UpdatedOn { get; set; }
	}
}
