﻿$(document).ready(function () {
	$('select').select2();
});