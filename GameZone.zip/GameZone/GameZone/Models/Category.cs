﻿namespace GameZone.Models;

public class Category : BaseEntity 
{
    public ICollection<Game> Games { get; set; } = new List<Game>();

	//public DateTime? CreatedOn { get; set; }
	//public DateTime? UpdatedOn { get; set; }

}