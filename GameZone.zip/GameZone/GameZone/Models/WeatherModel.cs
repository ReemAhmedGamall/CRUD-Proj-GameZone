﻿namespace GameZone.Models
{
	public class WeatherModel
	{
		public string CairoWeather { get; set; }
		public string NewYorkWeather { get; set; }

        public string CurrentTemperature { get; set; }
        public List<DailyWeather> CairoWeekWeather { get; set; }
        public List<DailyWeather> NewYorkWeekWeather { get; set; }

    }
	public class CurrentWeather
	{
		public double temperature { get; set; }
	}

	public class WeatherData
	{
		public CurrentWeather current_weather { get; set; }
        public DailyWeatherData daily { get; set; }
    }

    public class DailyWeatherData
    {
        public List<DateTime> time { get; set; }
        public List<double> temperature_2m_max { get; set; }
    }

    public class DailyWeather
    {
        public DateTime Date { get; set; }
        public double MaxTemperature { get; set; }
    }
}

